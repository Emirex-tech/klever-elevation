<?php

namespace App\Http\Controllers;

use App\Models\Wallet;
use Illuminate\Http\Request;

class WalletController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'address' => 'required',
        ]);

        $wallet = new Wallet;
        $wallet->wallet_name = $request->name;
        $wallet->wallet_address = $request->address;
        $wallet->save();

        return response()->json([
            'status' => 'success',
            'message' => 'wallet created successfully',
            
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Wallet  $wallet
     * @return \Illuminate\Http\Response
     */
    public function show(Wallet $wallet)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Wallet  $wallet
     * @return \Illuminate\Http\Response
     */
    public function edit(Wallet $wallet)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Wallet  $wallet
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Wallet $wallet, $id)
    {
        $request->validate([
            'name' => 'required',
            'address' => 'required',
        ]);

        $wallet = $wallet->find($id);
        if (!$wallet) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid wallet',
                
            ], 400);
        }

        $wallet->wallet_name = $request->name;
        $wallet->wallet_address = $request->address;
        $wallet->save();
        return response()->json([
            'status' => 'success',
            'message' => 'wallet updated successfully',
            
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Wallet  $wallet
     * @return \Illuminate\Http\Response
     */
    public function destroy(Wallet $wallet, $id)
    {
        $wallet = $wallet->find($id);
        if (!$wallet) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid wallet',
                
            ], 400);
        }

        $wallet->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'wallet deleted successfully',
            
        ], 200);
    }
}
