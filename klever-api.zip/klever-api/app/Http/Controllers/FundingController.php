<?php

namespace App\Http\Controllers;

use App\Models\Funding;
use App\Models\Wallet;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Notifications\GeneralNotification;
use Cloudinary;

class FundingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'amount' => 'required',
            'wallet_id' => 'required'
        ]);

        $wallet = Wallet::find($request->wallet_id);
        if (!$wallet) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid request',
            ], 400);
        }

        $funding = new Funding;
        $funding->user_id = Auth::id();
        $funding->amount = $request->amount;
        $funding->payment_method = $wallet->wallet_name.'('.$wallet->wallet_address.')';
        $funding->walet_id = $wallet->id;
        $funding->status = 'pending';
        $funding->save();
        $r_url  = '?tranx_id='.encrypt($funding->id).'&amount='.$funding->amount.'&wallet='.$wallet->wallet_name.'&address='.$wallet->wallet_address;

        return response()->json([
            'status' => 'success',
            'message' => 'funding initiated successfully',
            'trax_url' => $r_url
        ], 200);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Funding  $funding
     * @return \Illuminate\Http\Response
     */
    public function show(Funding $funding)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Funding  $funding
     * @return \Illuminate\Http\Response
     */
    public function edit(Funding $funding)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Funding  $funding
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $id = decrypt($id);
        $funding = Funding::find($id);
        if (!$funding) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid request',
            ], 400);
        }

        $funding->status = 'waiting approval';
        $funding->save();
        // notify the admins

        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'Funding Registered',
            'content' =>  substr($funding->user->name, 0, -3).'****'.' just funded $'.number_format($funding->amount, 4, '.', ','),
            'mail_content' => "Dear ". Auth::user()->name. ", <br/> This is to notify you that your funding of $".number_format($funding->amount, 4, '.', ',')." was registered successfully, kindly wait for admin's approval of your request as you review the details of your funding below: <br/><br/> 
            <p style='text-align:left;'>
            <p><strong>Trader Name:</strong> ". $funding->user->name ."</p>
            <p><strong>Payment Method:</strong> ". $funding->payment_method ."</p>
            <p><strong>Date:</strong> ". $funding->created_at->format('d-m-Y') ."</p>
            <p><strong>Amount Funded:</strong> $". number_format($funding->amount) ."</p>  
            <br/> Regards<br/> KLEVER ELEVATION  <br/> <br/><br/><br/><strong>If you  didn't initiate the above transaction kindly disregard. Thank you </strong></p>         
            ",
        ];
        $activity = (object)$notification_details;
        Auth::user()->notify(new GeneralNotification($activity));

        $roles = Role::all();
         $admin_notification = [
            'title' => 'New funding',
            'content' => substr($funding->user->name, 0, -3).'****'.' just funded $'.number_format($funding->amount, 4, '.', ','),
            'mail_content' => 'there is a new funding of $'.number_format($funding->amount, 4, '.', ','). ' from '.Auth::user()->name,
        ];
        $admin_activity = (object)$admin_notification;        
        foreach ($roles->where('name', 'admin') as $role) {
           $user = $role->user;
           $user->notify(new GeneralNotification($admin_activity));
        }

        return response()->json([
            'status' => 'success',
            'message' => 'funding registered successfully, we will notify you upon approval by admin. Thank you.',
        ], 200);
    }


    public function approvePayment(Request $request){
        $request->validate([
            'funding_id' => 'required',
            'image' => 'required'
        ]);

        $funding = Funding::find($request->funding_id);
        if (!$funding) {
           return response()->json([
            'status' => 'error',
            'message' => 'invalid request! funding not found'
           ], 400);
        }

        $image = Cloudinary::upload($request->file('image')->getRealPath())->getSecurePath();
        $funding->image = $image;
        $funding->save();

        return response()->json([
            'status' => 'success',
            'message' => 'payment proof uploaded successfully, kindy wait for admin\'s approval of your funding. Thank you.'
           ], 200);

    }


    public function approveFunding($id){
        $funding = Funding::find($id);
        if(!$funding){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $funding->status = 'approved';
        $funding->created_at =  now();
        $funding->save();  

        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'Funding Approved',
            'content' => substr($funding->user->name, 0, -3).'****'.' just funded $'.number_format($funding->amount, 2, '.', ','),            
            'mail_content' => 'Dear '. $funding->user->name.', <br/> This is to notify you that your funding of our '.number_format($funding->amount, 2, '.', ',').' has been approved by admin, you can check your balance for confirmation. Thank you.',
        ];

        $activity = (object)$notification_details;
        $funding->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'funding approved successfully',
            
        ], 200);

    }

     // all fundings management here
     public function declineFunding($id){
        $funding = Funding::find($id);
        if(!$funding){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $funding->status = 'declined';
        $funding->save();
        
         // notify the user of confirmed deposit
         $notification_details = [
            'title' => 'Funding Declined',
            'content' => substr($funding->user->name, 0, -3).'****'.' just funded with $'.number_format($funding->amount, 2, '.', ','),
            'mail_content' => 'Dear '. $funding->user->name.', <br/> This is to notify you that your funding of  '.number_format($funding->amount, 2, '.', ',').' has been declined by our admin, if you have any questions about this action, kindly contact our support for assistance. Thank you.',
        ];
        $activity = (object)$notification_details;
        $funding->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'funding declined successfully',
        ], 200);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Funding  $funding
     * @return \Illuminate\Http\Response
     */
    public function destroy(Funding $funding)
    {
        //
    }
}
