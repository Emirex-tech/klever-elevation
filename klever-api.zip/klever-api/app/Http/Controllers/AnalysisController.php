<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Investment;
use App\Models\Withdrawal;
use App\Models\Referral;
use App\Models\Country;
use App\Models\Plan;
use App\Models\Wallet;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\CryptoWallet;


class AnalysisController extends Controller
{
    public function histories(Request $request){
        $user = Auth::user();
        $withdrawals = $user->withdrawals;
        $investments = $user->investments->load(['user', 'plan', 'wallet']);
        $fundings = $user->fundings->load(['user', 'wallet']);
        $referrals = $user->referrals->load(['invited']);
        $plans = Plan::all();
        $wallets = Wallet::all();
        $cryptowallets = CryptoWallet::all();

        $investmentHistory = Investment::where('user_id', $user->id)->where('status', 'approved')->latest()->take(5)->get();
        if (!$investmentHistory->count() > 0) {
            $investmentHistory = Investment::where('user_id', $user->id)->where('status', 'completed')->latest()->take(5)->get();
        }        
        $toasts = collect([]);
        $notification = DB::table('notifications')
        ->inRandomOrder()
        ->first();

        if ($notification) {
            $data = json_decode($notification->data);
            $content = $data->content;
            $toasts->push($content);
        }
        

        
        return response()->json([
            'status' => 'success',
            'message' => 'histories fetched successfully',
            'withdrawals' => $withdrawals,
            'investments' => $investments,
            'referrals' => $referrals,
            'plans' => $plans,
            'wallets' => $wallets,
            'toasts' => $toasts,
            'fundings' => $fundings,
            'investmentHistory' => $investmentHistory,
            'cryptowallets' => $cryptowallets
        ], 200);
    }

    public function analysis(){

        $today_approved_investments = Investment::whereDate('created_at', date('Y-m-d', strtotime('today')))->where('status', 'approved')->sum('amount');
        $today_approved_withdrawals = Withdrawal::whereDate('created_at', date('Y-m-d', strtotime('today')))->where('status', 'approved')->sum('amount');
        $today_approved_referrals = Referral::whereDate('created_at', date('Y-m-d', strtotime('today')))->where('status', 'approved')->sum('amount');

        $yesterday_approved_investments = Investment::whereDate('created_at', date('Y-m-d', strtotime('yesterday')))->where('status', 'approved')->sum('amount');
        $yesterday_approved_withdrawals = Withdrawal::whereDate('created_at', date('Y-m-d', strtotime('yesterday')))->where('status', 'approved')->sum('amount');
        $yesterday_approved_referrals = Referral::whereDate('created_at', date('Y-m-d', strtotime('yesterday')))->where('status', 'approved')->sum('amount');

        $investment_percentage = 0;
        $investment_difference = $today_approved_investments - $yesterday_approved_investments;
        $investment_sum = $today_approved_investments + $yesterday_approved_investments;
        if ($investment_sum > 0) {
            $investment_ratio = $investment_difference/$investment_sum;
            $investment_percentage = $investment_ratio * 100;
        }

        $withdrawal_percentage = 0;
        $withdrawal_difference = $today_approved_withdrawals - $yesterday_approved_withdrawals;
        $withdrawal_sum = $today_approved_withdrawals + $yesterday_approved_withdrawals;
        if ($withdrawal_sum > 0) {
            $withdrawal_ratio = $withdrawal_difference/$withdrawal_sum;
            $withdrawal_percentage = $withdrawal_ratio * 100;
        }

        $referral_percentage = 0;
        $referral_difference = $today_approved_referrals - $yesterday_approved_referrals;
        $referral_sum = $today_approved_referrals + $yesterday_approved_referrals;
        if ($referral_sum > 0) {
            $referral_ratio = $referral_difference/$referral_sum;
            $referral_percentage = $referral_ratio * 100;
        }

        $total_investments = Auth::user()->totalInvestments();
        $total_withdrawals = Auth::user()->totalWithdrawals();
        $total_referrals = Auth::user()->totalreferrals();

        $investments = Investment::orderByDesc('id')->take(10)->get()->load('user');
        return response()->json([
            'status' => 'success',
            'message' => 'loaded analysis successfully',
            'today_investment' => $today_approved_investments,
            'today_withdrawal'=>$today_approved_withdrawals,
            'today_referral' => $today_approved_referrals,
            'investment_percent' => $investment_percentage,
            'referral_percent' => $referral_percentage,
            'withraw_percent' => $withdrawal_percentage,
            'investments' => $investments,
            
            'total_investments' => $total_investments,
            'total_withdrawals' => $total_withdrawals,
            'total_referrals' => $total_referrals
        ], 200);
    }


    public function wallets(){
        $account_balance = Auth::user()->accountBalance();
        $ref_bal = Auth::user()->referralBalance();
        $per_second_earning = Auth::user()->perSecondEarning();
        $current_earning = Auth::user()->currentEarning();
        $bonus_balanace = Auth::user()->topUpBal();
        $current_investment = Auth::user()->investments->where('status', 'approved')->sum('amount');


        
        return response()->json([
            'status' => 'success',
            'message' => 'wallets loaded successfully',
            'account_balance' => $account_balance,
            'ref_bal' => $ref_bal,
            'per_seconds_earning' => $per_second_earning,
            'current_earning' => $current_earning,
            'bonus_balanace' => $bonus_balanace,
            'current_investment' => $current_investment
        ], 200);
    }
}
