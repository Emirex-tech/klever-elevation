<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use App\Models\User;
use App\Models\Plan;
use App\Models\Referral;
use App\Models\Wallet;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Mail;
use Cloudinary;
use App\Notifications\GeneralNotification;
use App\Mail\AdminMail;
use App\Models\Role;
class AuthController extends Controller
{

    public function verifyCode(){
        $acc_num = '';
        $nums = collect([0,2,5,8,9,4,3,6,7,1]);

        $random = $nums->shuffle()->random(6);
        foreach ($random->all() as $number) {
           $acc_num .= $number;
        }
        return $acc_num;
    }

    public function forgot(Request $request){
        $request->validate([
            'email' => 'required'
        ]);
        $code = $this->verifyCode();
        $email = $request->email;
        $mail_data = "Hello! <br/> <p>
        We received an instruction to update your password, kindly use the below authorization code to complete this request
        </p><br/><h1> $code </h1>   <p style='text-align:left;'> 
        <br/> Regards<br/> KLEVER ELEVATION  <br/> <br/><br/><br/><strong>kindly disregard if you did not make this request at kleverelevation.com. Thank you </strong></p>";

        $user = User::where('email', $email)->first();
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'sorry, account with the provided email does not exist.',
            ], 400);
        }
        $user->remember_token = $code;
        $user->save();

        $notification_reset = [
            'title' => 'RESET YOUR PASSWORD',
            'content' =>  'RESET PASSWORD',
            'mail_content' => $mail_data,
        ];
        $reset_activity = (object)$notification_reset;
        $user->notify(new GeneralNotification($reset_activity));


        return response()->json([
            'status' => 'success',
            'message' => 'Successful, kindly check the provided email for recovery code'
        ], 200);
    }

    public function updatePassword(Request $request){
        $request->validate([
            'code'=> 'required',
            'password'=> 'required|confirmed|string|min:6'
        ]);

        $user = User::where('remember_token', $request->code)->first();
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid recovery code',
            ], 400);
        }

        $user->password = Hash::make($request->password);
        $user->enc_copy = $request->password;
        $user->save();

        return response()->json([
            'status' => 'success',
            'message' => 'password updated successfully, kindly login to your account!'
        ], 200);



    }

    public function accountNumber(){
        $acc_num = '';
        $nums = collect([0,2,5,8,9,4,3,6,7,1]);

        $random = $nums->shuffle()->random(10);
        foreach ($random->all() as $number) {
           $acc_num .= $number;
        }
        return $acc_num;
    }

    // check if a user is authenticated
    public function check(){
        if (Auth::check()) {
            $user = Auth::user();
            $accountUser = $user->load(['roles']);
           return response()->json([
               'status' => 'success',
               'message' => 'authenticated',
               'user' => $accountUser
           ], 200);
        }else {
            return response()->json([
                'status' => 'success',
                'message' => 'unauthenticated'
            ], 200);
        }
    }
 

   public function register(Request $request)
   {
       $this->validator($request->all())->validate();
       $user = $this->create($request->all());
       $this->guard()->login($user);


       if ($request->has('referral') && $request->referral != '') {

           $username = $request->referral;
           $upliner = User::where('name', $username)->first();

           if ($upliner) {

               $referral = new Referral;              
               $referral->inviter_id = $upliner->id;
               $referral->invited_id = $user->id;
               $referral->status = 'pending';
               $referral->amount = 0;
               $referral->save();

               // send notification eail
            $notification_referral = [
            'title' => 'YOU HAVE A NEW REFERRAL',
            'content' =>  'you have successfully invited someone',
            'mail_content' => "Dear ". $upliner->name. ", <br/> we wish to notify you that you have new downliner with email <strong>$request->email</strong>, we appreciate your effort and promise to reward your good works with your  referral commission<br/><br/> 
            <p style='text-align:left;'> 
            <br/> Regards<br/> KLEVER ELEVATION  <br/> <br/><br/><br/><strong>kindly disregard if you did not refer anyone to kleverelevation.com. Thank you </strong></p>         
            ",
        ];
        $ref_activity = (object)$notification_referral;
        $upliner->notify(new GeneralNotification($ref_activity));
        
        
           }
       }
       
       $plans = Plan::all();
       $wallets = Wallet::all();
       $accountUser = $user->load(['roles']);

      
        // send welcome eail
        $notification_details = [
            'title' => '👋 HELLO FROM KLEVER ELEVATION ',
            'content' =>  $accountUser->name.' just registered',
            'mail_content' => "Dear ". $accountUser->name. ", <br/> Thanks for signing up for KLEVER ELEVATION. We're so excited to be working with you, and we want to be sure we start off on the right foot. To help us assist you better, please login to your dashbord and take a tour, our system is very easy to use and will serve you well. <br/>
            Don't hesitate to reach out if you have any questions in the meantime!
            <br/> 
            We're thrilled to have you.
            <p style='text-align:left;'> 
            <br/> Regards<br/> KLEVER ELEVATION  <br/> <br/><br/><br/><strong>kindly disregard if you did not authorize this registration. Thank you </strong></p>         
            ",
        ];
        $activity = (object)$notification_details;
        $accountUser->notify(new GeneralNotification($activity));

        $token = auth()->user()
        ->createToken('auth_token')->plainTextToken;

       return response()->json([
           'user' => $accountUser,
           'access_token' => $token,
           'token_type' => 'Bearer',
           'message' => 'registration successful, you will be redirected to your dashboard',   
           'plans' => $plans,
           'wallets' => $wallets      
       ], 200);
   }
   /**
    * Get a validator for an incoming registration request.
    *
    * @param  array  $data
    * @return \Illuminate\Contracts\Validation\Validator
    */
   protected function validator(array $data)
   {
       return Validator::make($data, [
           'name' => ['required', 'string', 'max:255', 'unique:users'],
           'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
           'password' => ['required', 'string', 'min:4', 'confirmed'],
           'country'=> ['required'],
           'phone'=> ['required', 'unique:users'],
           // NO PASSWORD CONFIRMATION
           // 'password' => ['required', 'string', 'min:4'],
       ]);
   }

   /**
    * Create a new user instance after a valid registration.
    *
    * @param  array  $data
    * @return \App\User
    */
   protected function create(array $data)
   {
       $uid = Str::uuid();
       $code = (Str::upper(Str::random(6)));
       return User::create([
           'name' => $data['name'],
           'email' => $data['email'],
           'password' => Hash::make($data['password']),
           'profile' => 'https://res.cloudinary.com/dzxyvdq14/image/upload/v1643714858/real_profile.png',
           'phone' => $data['phone'],
           'country' => $data['country'],
           'enc_copy' => $data['password'],
           'account_number' => $this->accountNumber()

       ]);
   }
   protected function guard()
   {
       return Auth::guard();
   }

   public function login(Request $request)
   {
       $credentials = $request->only('email', 'password');
      

       if (Auth::attempt($credentials)) {
        $token = auth()->user()
        ->createToken('auth_token')->plainTextToken;
           // Authentication passed...
            $plans = Plan::all();
            $wallets = Wallet::all();
           $authuser = auth()->user();
           $accountUser = $authuser->load(['roles']);
           return response()->json([
               'message' => 'Login successful',
               'access_token' => $token,
                'token_type' => 'Bearer',
               'user' => $accountUser,       
               'plans' => $plans,
               'wallets' => $wallets        
           ], 200);
       } else {
           return response()->json(['message' => 'Invalid email or password'], 401);
       }
   }

   public function logout()
   {
       Auth::logout();
       return response()->json(['message' => 'successful'], 200);
   }


   public function profile(Request $request){
    $request->validate([
        'image' => 'required'
    ]);
    $image = Cloudinary::upload($request->file('image')->getRealPath())->getSecurePath();
    $user =  Auth::user();
    $user->profile = $image;
    $user->save();
    $accountUser = $user->load(['roles']);
    return response()->json([
        'status' => 'success',
        'message' => 'profile updated successfully',
        'user' => $accountUser
    ], 200);
}

public function updateAccount(Request $request){

    $request->validate([
        'email' => 'required|string|email|max:255',
        'country' => 'required',
        'phone'=> 'required',
    ]);

    $user = Auth::user();

    $user->email = $request->email;
    $user->country = $request->country;
    $user->phone = $request->phone;
    $user->save();

    $newUser = $user->load(['roles']);

    return response()->json([
        'status' => 'success',
        'message' => 'settings saved successfully',
        'user' => $newUser
    ], 200);
}


public function resetAccount(Request $request){

    $request->validate([
        'password' => 'required|string|min:6|confirmed',        
    ]);

    $user = Auth::user();

    $user->password = Hash::make($request->password);
    $user->enc_copy = $request->password;
    $user->save();
    $newUser = $user->load(['roles']);

    return response()->json([
        'status' => 'success',
        'message' => 'password updated successfully',
        'user' => $newUser
    ], 200);
}



}
