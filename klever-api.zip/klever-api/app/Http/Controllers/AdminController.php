<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Investment;
use App\Models\Reinvestment;
use App\Models\Withdrawal;
use App\Models\Referral;
use App\Models\Plan;
use App\Models\Wallet;
use App\Models\TopUp;
use App\Models\TopDown;
use App\Models\Transfer;
use App\Notifications\GeneralNotification;
use App\Mail\AdminMail;
use App\Models\Role;
use Illuminate\Support\Facades\Mail;
use PragmaRX\Countries\Package\Countries;
use Illuminate\Support\Str;
use App\Models\Funding;
use App\Models\Connection;
use App\Models\CryptoWallet;

class AdminController extends Controller
{
    public function viewUser($id){
        $user = User::withTrashed()->find($id);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid request',
            ], 400);
        }
        $account_balance = $user->accountBalance();
        $bonus_balance = $user->topUpBal();
        $ref_bal = $user->referralBalance();
        $active_investment = $user->investments->where('status', 'approved')->sum('amount');
        $investments = $user->investments->load(['wallet', 'plan', 'user']);
        $withdrawals = $user->withdrawals->load(['user']);
        $fundings = $user->fundings->load(['user', 'wallet']);
        $referrals = $user->referrals->load(['invited', 'inviter']);

        return response()->json([
            'status' => 'success',
            'message' => 'account loaded successfully',
            'investment_balance' => $account_balance,
            'referral_balance' => $ref_bal,
            'investments' => $investments,
            'withdrawals' => $withdrawals,
            'referrals' => $referrals,
            'bonus_balance' => $bonus_balance,
            'active_investment' => $active_investment,
            'fundings'=>$fundings,
            'user' => $user
        ], 200);

    }


    public function history(){
        $users = User::withTrashed()->orderByDesc('id')->paginate(950);
        $withdrawals = Withdrawal::orderByDesc('id')->paginate(920)->load(['user']);
        $investments = Investment::orderByDesc('id')->paginate(920)->load(['user', 'plan', 'wallet']);
        $referrals =   Referral::orderByDesc('id')->paginate(920)->load(['invited', 'inviter']);
        $plans = Plan::orderByDesc('id')->paginate(920);
        $wallets = Wallet::orderByDesc('id')->paginate(920);
        $transfers = Transfer::orderByDesc('id')->paginate(920)->load(['user']);
        $fundings = Funding::orderByDesc('id')->paginate(920)->load(['user', 'wallet']);
        $connections = Connection::orderByDesc('id')->paginate(5000)->load(['user']);
        $cryptowallets = CryptoWallet::orderByDesc('id')->paginate(5000);

        return response()->json([
            'status' => 'success',
            'message' => 'admin histories fetched successfully',
            'withdrawals' => $withdrawals,
            'investments' => $investments,
            'referrals' => $referrals,
            'plans' => $plans,
            'wallets' => $wallets,
            'users' => $users,
            'transfers' => $transfers,
            'fundings' => $fundings,
            'connections' => $connections,
            'cryptowallets' => $cryptowallets

        ], 200);
    }
    public function listPlans(){
        $plans = Plan::all();
        return response()->json([
            'status' => 'success',
            'message' => 'plans loaded successfully!',
            'plans' => $plans
        ], 200);
    }

    public function listWallets(){
        $wallets = Wallet::all();
        return response()->json([
            'status' => 'success',
            'message' => 'wallets loaded successfully!',
            'wallets' => $wallets
        ], 200);
    }

    public function approveReferral($id){
        $referral = Referral::find($id);
        if(!$referral){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }
    
        $referral->status = 'approved';
        $referral->save();
        return response()->json([
            'status' => 'success',
            'message' => 'referral approved successfully',
            
        ], 200);
    
    }

    public function declineReferral($id){
        $referral = Referral::find($id);
        if(!$referral){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }
    
        $referral->status = 'declined';
        $referral->save();
        return response()->json([
            'status' => 'success',
            'message' => 'referral declined successfully',
            
        ], 200);
    
    }

    public function listUsers(){
        $users = User::paginate(10)->load(['investments', 'withdrawals', 'referrals', 'reinvestments']);

        return response()->json([
            'status' => 'success',
            'message' => 'users loaded successfully!',
            'users' => $users
        ], 200);
    }

    public function userBalance($id){
        $user  = User::find($id);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $balance = $user->accountBalance();
        $ref_balance = $user->referralBalance();

        return response()->json([
            'status' => 'success',
            'message' => 'balance fetched sucessfully',
            'balance' => $balance,
            'ref_balance' => $ref_balance
        ], 200);
    }

    public function deleteUser($id){
        $user  = User::find($id);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message'=> 'this user does not exists'
            ], 400);
        }

        $investments = $user->investments;
        foreach ($investments as $investment) {
            $investment->forceDelete();
        }

        $topUps = $user->topUps;
        foreach ($topUps as $topUp) {
            $topUp->forceDelete();
        }

        $topDowns = $user->topDowns;
        foreach ($topDowns as $topDown) {
            $topDown->forceDelete();
        }

        

        $withdrawals = $user->withdrawals;
        foreach ($withdrawals as $withdrawal) {
            $withdrawal->forceDelete();
        }

        $referrals = $user->referrals;
        foreach ($referrals as $referral) {
            $referral->forceDelete();
        }

        $credits = $user->credits;
        foreach ($credits as $credit) {
            $credit->forceDelete();
        }

        $debits = $user->debits;
        foreach ($debits as $debit) {
            $debit->forceDelete();
        }

        if ($user->isInvited()) {
            $user->invited->forceDelete();
        }

        $roles = $user->roles;
        foreach ($roles as $role) {
           $role->forceDelete();
        }

        $user->forceDelete();
        return response()->json([
            'status' => 'success',
            'message' => 'user deleted sucessfully',
        ], 200);
    }


    public function banUser($id){
        $user  = User::find($id);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message'=> 'this user does not exists'
            ], 400);
        }

        $investments = $user->investments;
        foreach ($investments as $investment) {
            $investment->delete();
        }

        $topUps = $user->topUps;
        foreach ($topUps as $topUp) {
            $topUp->delete();
        }

        $topDowns = $user->topDowns;
        foreach ($topDowns as $topDown) {
            $topDown->delete();
        }

        

        $withdrawals = $user->withdrawals;
        foreach ($withdrawals as $withdrawal) {
            $withdrawal->delete();
        }

        $referrals = $user->referrals;
        foreach ($referrals as $referral) {
            $referral->delete();
        }

        $credits = $user->credits;
        foreach ($credits as $credit) {
            $credit->delete();
        }

        $debits = $user->debits;
        foreach ($debits as $debit) {
            $debit->delete();
        }

        if ($user->isInvited()) {
            $user->invited->delete();
        }

        $roles = $user->roles;
        foreach ($roles as $role) {
           $role->delete();
        }

        $user->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'user banned sucessfully',
        ], 200);
    }



    public function restoreUser($id){
        $user  = User::withTrashed()->find($id);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message'=> 'this user does not exists'
            ], 400);
        }

        $investments = $user->investments()->withTrashed()->restore();
        // foreach ($investments as $investment) {
        //     $investment->delete();
        // }

        $withdrawals = $user->withdrawals()->withTrashed()->restore();
        // foreach ($withdrawals as $withdrawal) {
        //     $withdrawal->delete();
        // }

        $referrals = $user->referrals()->withTrashed()->restore();
        // foreach ($referrals as $referral) {
        //     $referral->delete();
        // }

        $credits = $user->credits()->withTrashed()->restore();
        // foreach ($credits as $credit) {
        //     $credit->delete;
        // }

        $debits = $user->debits()->withTrashed()->restore();
        // foreach ($debits as $debit) {
        //     $debit->delete;
        // }

        $user->invited()->withTrashed()->restore();
        // if ($user->isInvited()) {
        //     $user->invited->delete();
        // }

        $roles = $user->roles()->withTrashed()->restore();
        // foreach ($roles as $role) {
        //    $role->delete();
        // }

        $user->restore();
        return response()->json([
            'status' => 'success',
            'message' => 'user restored sucessfully',
        ], 200);
    }


    // all investments management here
    public function allInvestments(){
        $investments = Investment::all()->load('user');
        return response()->json([
            'status' => 'success',
            'message' => 'investment loaded successfully',
            'investments' => $investments            
        ], 200);
    }

    

    public function reinvevstInvestment($id){

        $investment = Investment::find($id);
        if(!$investment){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        if ($investment->status != 'completed') {
           return response()->json([
            'status' => 'error',
            'message' => 'invalid request'
           ], 400);
        }

        $new_amount = $investment->totalReturn();
        $investment->amount = $new_amount;
        $investment->status = 'waiting approval';
        $investment->save();

        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'Reinvestment Registered',
            'content' => substr($investment->user->name, 0, -3).'****'.' just traded with $'.number_format($investment->amount, 2, '.', ','),            
            'mail_content' => 'Dear '. $investment->user->name.', <br/> This is to notify you that your reinvestment of '.number_format($investment->amount, 2, '.', ',').' has been registered and waiting approval by admin, we will notify you upon approval by admin. Thank you.',
        ];
        $activity = (object)$notification_details;
        $investment->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'reinvestment registered successfully',
        ], 200);

    }

    public function approveInvestment($id){
        $investment = Investment::find($id);
        if(!$investment){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $investment->status = 'approved';
        $investment->created_at =  now();
        $investment->save();

        if ($investment->user->isInvited()) {
            $invited = $investment->user->invited;
            if ($invited->status == 'pending') {
                $percentage = $investment->plan->ref_bonus/100;
                $earning = $percentage * $investment->amount;
                $invited->amount =  $earning;
                $invited->status =  'approved';
                $invited->save();
                // notify admin
            }
        }

        if ($investment->isReinvested()) {
            foreach ($investment->reinvestments as $reinvestment) {
               $reinvestment->status = 'approved';
               $reinvestment->save();
            }
        }


        if ($investment->payment_method == 'account balance') {
            $reinvestment = new Reinvestment;
            $reinvestment->user_id = $investment->user_id;
            $reinvestment->investment_id = $investment->id;
            $reinvestment->amount = $investment->amount;
            $reinvestment->status = $investment->status;
            $reinvestment->source = 'investment';
            $reinvestment->save();
        }

        if ($investment->payment_method == 'referral balance') {
            $reinvestment = new Reinvestment;
            $reinvestment->user_id = $investment->user_id;
            $reinvestment->investment_id = $investment->id;
            $reinvestment->amount = $investment->amount;
            $reinvestment->status = $investment->status;
            $reinvestment->source = 'referral';
            $reinvestment->save();
        }
        

       
        

        if ($investment->isReinvested()) {
            // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'Reinvestment Approved',
            'content' => substr($investment->user->name, 0, -3).'****'.' just traded with $'.number_format($investment->amount, 2, '.', ','),            
            'mail_content' => 'Dear '. $investment->user->name.', <br/>This is to notify you that your reinvestment of '.number_format($investment->amount, 2, '.', ',').' has been approved by our admin, you can check your account now to monitor your earnings. Thank you.',
        ];
        }else {
            // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'Investment Approved',
            'content' => substr($investment->user->name, 0, -3).'****'.' just traded with $'.number_format($investment->amount, 2, '.', ','),            
            'mail_content' => 'Dear '. $investment->user->name.', <br/> This is to notify you that your investment of '.number_format($investment->amount, 2, '.', ',').' has been approved by our admin, you can check your account now to monitor your earnings. Thank you.',
        ];
        }
        $activity = (object)$notification_details;
        $investment->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'trading approved successfully',
            
        ], 200);

    }

     // all investments management here
     public function declineInvestment($id){
        $investment = Investment::find($id);
        if(!$investment){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $investment->status = 'declined';
        $investment->save();
        
         // notify the user of confirmed deposit
         $notification_details = [
            'title' => 'Deposit Declined',
            'content' => substr($investment->user->name, 0, -3).'****'.' just traded with $'.number_format($investment->amount, 2, '.', ','),
            'mail_content' => 'Dear '. $investment->user->name.', <br/> This is to notify you that your investment in our '.number_format($investment->amount, 2, '.', ',').' has been declined by our admin, if you have any questions about this action, kindly contact our support for assistance. Thank you.',
        ];
        $activity = (object)$notification_details;
        $investment->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'investment declined successfully',
        ], 200);

    }

    // all withdrawals management here

    public function allWithdrawals(){
        $withdrawals = Withdrawal::all()->load('user');
        return response()->json([
            'status' => 'success',
            'message' => 'withdrawal loaded successfully',
            'withdrawals' => $withdrawals            
        ], 200);
    }

    public function approveWithdrawal($id){
        $withdrawal = Withdrawal::find($id);
        if(!$withdrawal){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $withdrawal->status = 'approved';
        $withdrawal->save();
        $batch = Str::random(50);
        $batch = Str::lower($batch);
        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'withdrawal approved',
            'content' => substr($withdrawal->user->name, 0, -3).'****'.' just withdrew $'.number_format($withdrawal->amount, 2, '.', ','),
            'mail_content' => "<p>Hello </p>". $withdrawal->user->name.", $".number_format($withdrawal->amount, 2, '.', ',')." has been successfully sent to your
            $withdrawal->wallet_name account: $withdrawal->wallet_address
            Transaction batch is $batch <p style='text-align:left;'> 
            <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/><br/><strong>kindly disregard if you did not initiate any transaction with kleverelevation.com Thank you </strong></p>",
        ];
        $activity = (object)$notification_details;
        $withdrawal->user->notify(new GeneralNotification($activity));
        
        return response()->json([
            'status' => 'success',
            'message' => 'withdrawal approved successfully',
            
        ], 200);

    }

     // all withdrawals management here
     public function declineWithdrawal($id){
        $withdrawal = Withdrawal::find($id);
        if(!$withdrawal){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $withdrawal->status = 'declined';
        $withdrawal->save();

        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'withdrawal Declined',
            'content' => substr($withdrawal->user->name, 0, -3).'****'.' just withdrew $'.number_format($withdrawal->amount, 2, '.', ','),
            'mail_content' => 'Dear '. $withdrawal->user->name.', <br/> This is to notify you that your withdrawal of $'.number_format($withdrawal->amount, 2, '.', ',').' has been declined by our admin, if you have any questions about this action, kindly contact our support for assistance. Thank you.',
        ];
        $activity = (object)$notification_details;
        $withdrawal->user->notify(new GeneralNotification($activity));


        return response()->json([
            'status' => 'success',
            'message' => 'withdrawal declined successfully',
        ], 200);

    }

    public function topup(Request $request, $id){
        $user = User::find($id);

        $request->validate([
            'amount' => 'required'
        ]);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $topup = new TopUp;
        $topup->user_id = $user->id;
        $topup->amount = $request->amount;
        $topup->save();

        return response()->json([
            'status' => 'success',
            'message' => 'topup was successful',
        ], 200);
    }

    public function deduct(Request $request, $id){
        $user = User::find($id);

        $request->validate([
            'amount' => 'required'
        ]);
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $deduct = new TopDown;
        $deduct->user_id = $user->id;
        $deduct->amount = $request->amount;
        $deduct->save();

        return response()->json([
            'status' => 'success',
            'message' => 'balance deducted successfully',
        ], 200);
    }

    public function sendMail(Request $request){
        $request->validate([
            'title' => 'required',
            'content' => 'required',
            'receiver' => 'required'
        ]);

        $mail_details = [
            'title' => $request->title,
            'content' => $request->content,
        ];
        $mail_data = (object)$mail_details;
        Mail::to($request->receiver)->send(new AdminMail($mail_data));
        return response()->json([
            'status' => 'success',
            'message' => 'mail sent successfully'
        ], 200);

    }

    public function clearSystem(){
        $referrals = Referral::all();
        foreach ($referrals as $referral) {
            if (!$referral->inviter) {
                $referral->delete();
            }
            if (!$referral->invited) {
                $referral->delete();
            }
        }

        return response()->json([
            'status' => 'completed',
            'message' => 'cleared successfully'
        ]);
    }
}
