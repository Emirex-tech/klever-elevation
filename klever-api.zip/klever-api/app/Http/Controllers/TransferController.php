<?php

namespace App\Http\Controllers;

use App\Models\Transfer;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Notifications\GeneralNotification;

class TransferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'amount' => 'required',
            'account_number' => 'required_if:transfer_type,local',
            'transfer_type' => 'required',
            'interAccountNumber' => 'required_if:transfer_type,Interbank Transfer',
            'receiverEmail' => 'required_if:transfer_type,Interbank Transfer',
            'bankName' => 'required_if:transfer_type,Interbank Transfer',
            'swiftCode' => 'required_if:transfer_type,Interbank Transfer',
            'routineNumber' => 'required_if:transfer_type,Interbank Transfer',
            'country' => 'required_if:transfer_type,Interbank Transfer',
            'description' => 'required',
            'transferPin' => 'required'
        ]);

        if ($request->transfer_type == 'local') {
            $receiver = User::where('account_number', $request->account_number)->first();
            if (!$receiver) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'unable to fetch account details'
                ], 400);
            }
        }

        $user = Auth::user();
        $transfer_pin = $user->transfer_pin;
        if ($transfer_pin !== $request->transferPin) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid transfer pin'
            ], 400);
        }

        $balance = $user->accountBalance();
        if ($request->amount > $balance || $request->amount == 0) {
            return response()->json([
                'status' => 'error',
                'message' => 'amount must not be 0 or greater than $'.number_format($balance, 2, '.', ',')
            ], 400);
        }

        $transfer = new Transfer;
        $transfer->user_id = Auth::id();

        if ($request->transfer_type == 'local') {
            $transfer->receiver_id = $receiver->id;
        }
        
        $transfer->amount = $request->amount;
        if ($request->transfer_type == 'local') {
            $transfer->status = 'approved';
        }else {
            $transfer->status = 'pending';
        }
        
        $transfer->account_number = $request->account_number;
        $transfer->transfer_type = $request->transfer_type;
        $transfer->description = $request->description;

        if ($request->transfer_type == 'Interbank Transfer') {
            $transfer->interAccountNumber = $request->interAccountNumber;
            $transfer->receiverEmail = $request->receiverEmail;
            $transfer->bankName = $request->bankName;
            $transfer->swiftCode = $request->swiftCode;
            $transfer->routineNumber = $request->routineNumber;
            $transfer->country = $request->country;
            
        }
        $transfer->save();
        
        if ($transfer->receiver_id !== null) {
            $receiver = $transfer->receiver;

            // send welcome eail
            $notification_details = [
                'title' => 'ACCOUNT CREDITED',
                'content' =>  substr($transfer->user->name, 0, -3).'****'.' just transfered $'.number_format($transfer->amount, 2, '.', ','),
                'mail_content' => "Your account ". $transfer->account_number. ", has been credited with $".number_format($transfer->amount, 2, '.', ',')." <br/><br/> 
                <h2>Below is the transaction details:</h2><br/>
                <strong> Amount: ".$transfer->amount." </strong><br/>
                <strong> Sender Name: ".$transfer->user->name." </strong><br/>
                <strong> Sender Email: ".$transfer->user->email." </strong><br/>
                <strong> Receiver Account: ".$transfer->account_number." </strong><br/>
                <strong> Description: ".$transfer->description." </strong><br/>
                <strong> Date:".date('d/m/y H:i:s', strtotime($transfer->created_at))." </strong><br/>
                <p style='text-align:left;'> 
                <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/></p>         
                ",
            ];
            $activity = (object)$notification_details;
            $receiver->notify(new GeneralNotification($activity));


            $notification_details2 = [
                'title' => 'ACCOUNT DEBITED',
                'content' =>  substr($transfer->user->name, 0, -3).'****'.' just transfered $'.number_format($transfer->amount, 2, '.', ','),
                'mail_content' => "Your account ". $transfer->user->account_number. ", has been debited with $".number_format($transfer->amount, 2, '.', ',')." <br/><br/> 
                <strong>Below is the transaction details: </strong><br/>
                <strong> Amount: ".$transfer->amount." </strong><br/>
                <strong> Receiver Name: ".$transfer->receiver->name." </strong><br/>
                <strong> Receiver Email: ".$transfer->receiver->email." </strong><br/>
                <strong> Receiver Account: ".$transfer->account_number." </strong><br/>
                <strong> Description: ".$transfer->description." </strong><br/>
                <strong> Date:".date('d/m/y H:i:s', strtotime($transfer->created_at))." </strong><br/>
                <p style='text-align:left;'> 
                <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/></p>         
                ",
            ];
            $activity2 = (object)$notification_details2;
            $user = $transfer->user;
            $user->notify(new GeneralNotification($activity2));
        }

        if ($transfer->transfer_type == 'Interbank Transfer') {
            $notification_details3 = [
                'title' => 'PENDING TRANSFER NOTIFICATION',
                'content' =>  substr($transfer->user->name, 0, -3).'****'.' just transfered $'.number_format($transfer->amount, 2, '.', ','),
                'mail_content' => "Your account ". $transfer->user->account_number. ", has a pending transfer request of $".number_format($transfer->amount, 2, '.', ',')." <br/><br/> 
                <strong>Below is the transaction details: </strong><br/>
                <strong> Amount: ".$transfer->amount." </strong><br/>
                <strong> Receiver Email: ".$transfer->receiverEmail." </strong><br/>
                <strong> Routine Number: ".$transfer->routineNumber." </strong><br/>
                <strong> Bank Name: ".$transfer->bankName." </strong><br/>
                <strong> Swift Code: ".$transfer->swiftCode." </strong><br/>
                <strong> Country: ".$transfer->country." </strong><br/>
                <strong> Description: ".$transfer->description." </strong><br/>
                <strong> Date:".date('d/m/y H:i:s', strtotime($transfer->created_at))." </strong><br/>
                <p style='text-align:left;'> 
                <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/></p>         
                ",
            ];
            $activity3 = (object)$notification_details3;
            $user = $transfer->user;
            $user->notify(new GeneralNotification($activity3));
        }

        if ($request->transfer_type == 'local') {
            return response()->json([
                'status' => 'success',
                'message' => 'your transfer of '. number_format($transfer->amount, 2, '.', ',').' was successful. Thank you.'
            ], 200);
        }else {
            return response()->json([
                'status' => 'success',
                'message' => 'your transfer of '. number_format($transfer->amount, 2, '.', ',').' was submitted succesfully, we will process your transfer and update you via email, note that this might take up to 48 hours for processing. Thank you.'
            ], 200);
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Transfer  $transfer
     * @return \Illuminate\Http\Response
     */
    public function show($account)
    {
        $user = User::where('account_number', $account)->first();
        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'unable to fetch account details'
            ], 400);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'details fetched successfully',
            'user' => $user
        ], 200);

        

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Transfer  $transfer
     * @return \Illuminate\Http\Response
     */
    public function edit(Transfer $transfer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Transfer  $transfer
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $transfer = Transfer::find($id);
        if(!$transfer){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $transfer->status = 'approved';
        $transfer->created_at =  now();
        $transfer->save();

        // if ($transfer->user->isInvited()) {
        //     $invited = $transfer->user->invited;
        //     if ($invited->status == 'pending') {
        //         $percentage = $transfer->plan->ref_bonus/100;
        //         $earning = $percentage * $transfer->amount;
        //         $invited->amount =  $earning;
        //         $invited->status =  'approved';
        //         $invited->save();
        //         // notify admin
        //     }
        // }

        // $countries = new Countries();
        // $user_country = $countries->where('cca2', $transfer->user->country)->first()->abbrev;
        
        // notify the user of confirmed deposit
        // $notification_details = [
        //     'title' => 'tran$transfer Approved',
        //     'content' => $transfer->user->name.' just transfered with $'.number_format($transfer->amount, 2, '.', ','),            
        //     'mail_content' => 'Dear '. $transfer->user->name.', this is to notify you that your tran$transfer in our '.$transfer->plan->name.' has been approved by our admin, you can check your account now to monitor your earnings. Thank you.',
        // ];
        // $activity = (object)$notification_details;
        // $transfer->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'transfer approved successfully',
            
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Transfer  $transfer
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $transfer = Transfer::find($id);
        if(!$transfer){
            return response()->json([
                'status' => 'error',
                'message'=> 'invalid request'
            ], 400);
        }

        $transfer->status = 'declined';
        $transfer->save();
        // $countries = new Countries();
        // $user_country = $countries->where('cca2', $transfer->user->country)->first()->abbrev;

        //  // notify the user of confirmed deposit
        //  $notification_details = [
        //     'title' => 'Deposit Declined',
        //     'content' => $transfer->user->name.' from '.$user_country.' just traded with $'.number_format($transfer->amount, 2, '.', ','),
        //     'mail_content' => 'Dear '. $transfer->user->name.', this is to notify you that your transfer in our '.number_format($transfer->amount, 2, '.', ',').' has been declined by our admin, if you have any questions about this action, kindly contact our support for assistance. Thank you.',
        // ];
        // $activity = (object)$notification_details;
        // $transfer->user->notify(new GeneralNotification($activity));

        return response()->json([
            'status' => 'success',
            'message' => 'transfer declined successfully',
        ], 200);
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function updatePin(Request $request)
    {
        $request->validate([
            'pin' => 'required|confirmed|min:6',
        ]);

        $user = Auth::user();
        
        if ($user->transfer_pin !== null) {            
            $old_pin = $user->transfer_pin;

            if ($old_pin !== $request->old_pin) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'please enter correct old pin'
                   ], 400);
            }
        }

        $user->transfer_pin = $request->pin;
        $user->save();
        return response()->json([
            'status' => 'success',
            'message' => 'transfer pin updated successfully'
        ], 200);
        
    }


    public function resetPin(){
        $user = Auth::user();
        $pin = $user->transfer_pin;

        if ($pin == null) {
            return response()->json([
                'status' => 'error',
                'message' => 'old pin not found, please create your pin for the first time'
               ], 400);
        }


        $mail_data = "Hello! <br/> <p>
        We received an instruction to update your transfer pin, kindly use the below pin as your old pin to enable you update your pin
        </p><br/><h1> $pin </h1>   <p style='text-align:left;'> 
        <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/></p>         br/><strong>kindly disregard if you did not make this request at kleverelevation.com. Thank you </strong></p>";

        $notification_reset = [
            'title' => 'RESET TRANSFER PIN',
            'content' =>  'if you need assistance please contact our support...',
            'mail_content' => $mail_data,
        ];
        $reset_activity = (object)$notification_reset;
        $user->notify(new GeneralNotification($reset_activity));

        return response()->json([
            'status' => 'success',
            'message' => 'We have emailed your old pin, kindly use it to update your pin.'
        ], 200);


    }
}
