<?php

namespace App\Http\Controllers;

use App\Models\Plan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PlanController extends Controller
{

    /**
     * @param string $comma_separated_string e.g. "a,b, c"
     * @return array The values between the comma's in the given string, ignoring any white space between values/separators
     */
    function explode_ignoring_whitespace(string $comma_separated_string): array
    {
        // Cheeky way to explode only "a" and "b, c" from "a,b, c"
        return preg_split('/,/', $comma_separated_string);
        
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'durations_copy' => 'required',
            'name' => 'required',
            'min_amount' => 'required',
            'max_amount' => 'required',
            'ref_bonus' => 'required',
            'description' => 'required',
            'daily_roi' => 'required',
            'daily_roi_max' => 'required'
        ]);

        $plan = new Plan;
        $durations_list = $this->explode_ignoring_whitespace($request->durations_copy);
        $durations = collect($durations_list); 

        $plan->user_id= Auth::id();
        $plan->durations= $durations;
        $plan->durations_copy= $request->durations_copy;
        $plan->name= $request->name;
        $plan->min_amount= $request->min_amount;
        $plan->max_amount= $request->max_amount;
        $plan->ref_bonus= $request->ref_bonus;
        $plan->description= $request->description;
        $plan->daily_roi_percent= $request->daily_roi;
        $plan->max_daily_roi_percent = $request->daily_roi_max;
        $plan->save();
        return response()->json([
            'status' => 'success',
            'message' => 'plan created successfully',            
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function show(Plan $plan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function edit(Plan $plan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Plan $plan, $id)
    {
        $request->validate([
            'durations_copy' => 'required',
            'name' => 'required',
            'min_amount' => 'required',
            'max_amount' => 'required',
            'ref_bonus' => 'required',
            'description' => 'required',
            'daily_roi' => 'required',
            'daily_roi_max' => 'required'
        ]);


        $plan = $plan->find($id);
        if (!$plan) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid plan',
                
            ], 400);
        }

        $durations_list = $this->explode_ignoring_whitespace($request->durations_copy);
        $durations = collect($durations_list);  

        $plan->user_id= Auth::id();
        $plan->durations= $durations;
        $plan->durations_copy= $request->durations_copy;
        $plan->name= $request->name;
        $plan->min_amount= $request->min_amount;
        $plan->max_amount= $request->max_amount;
        $plan->ref_bonus= $request->ref_bonus;
        $plan->description= $request->description;
        $plan->daily_roi_percent= $request->daily_roi;
        $plan->max_daily_roi_percent = $request->daily_roi_max;

        $plan->save();
        return response()->json([
            'status' => 'success',
            'message' => 'plan updated successfully',            
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Plan $plan, $id)
    {
        $plan = $plan->find($id);
        if (!$plan) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid plan',
                
            ], 400);
        }

        $plan->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'plan deleted successfully',            
        ], 200);
    }
}
