<?php

namespace App\Http\Controllers;

use App\Models\Investment;
use App\Models\Withdrawal;
use App\Models\Plan;
use App\Models\Wallet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Notifications\GeneralNotification;
use App\Models\Role;
use PragmaRX\Countries\Package\Countries;
use Cloudinary;

class InvestmentController extends Controller
{
   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $plans = Plan::all();
        $wallets = Wallet::all();
        return response()->json([
            'status' => 'success',
            'message' => 'plans fetched successfully',
            'plans' => $plans,
            'wallets' => $wallets,
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function plans(Request $request)
    {
        $plans = Plan::all();
        $latest_Investments = Investment::orderByDesc('id')->take(10)->get()->load('user');
        $latest_withdrawals = Withdrawal::orderByDesc('id')->take(10)->get()->load('user');

        return response()->json([
            'status' => 'success',
            'message' => 'plans were loaded successfully',
            'plans' => $plans,
            'investments' => $latest_Investments,
            'withdrawals' => $latest_withdrawals
        ], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'plan_id' => 'required',
            'wallet_id' => 'required',
            'amount' => 'required|integer|min:1',
            'duration' => 'required',
        ]);

        $plan = Plan::find($request->plan_id);
        $user = Auth::user();

        if ($request->wallet_id == 'account balance' && $user->accountBalance() < $request->amount) {
            return response()->json([
                'status' => 'error',
                'message' => 'insufficient account balance',
            ], 400);
        }
        if ($request->wallet_id == 'referral balance' && $user->referralBalance() < $request->amount) {
            return response()->json([
                'status' => 'error',
                'message' => 'insufficient referral balance',
            ], 400);
        }

        $payment_method = '';
        $investment_status = '';
        if ($request->wallet_id == 'account balance' || $request->wallet_id == 'referral balance') {
            $wallet = Wallet::first();
            $payment_method = $request->wallet_id;  
            $investment_status = 'waiting approval';
        }else {
            $wallet = Wallet::find($request->wallet_id);
            $payment_method = $wallet->wallet_name.' ('.$wallet->wallet_address.')';
            $investment_status = 'pending';

        }
        
        
        if (!$plan) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid request',
            ], 400);
        }

        if (!$wallet) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid request',
            ], 400);
        }
        
        if ($request->amount < $plan->min_amount  || $request->amount > $plan->max_amount) {
            return response()->json([
                'status' => 'error',
                'message' => 'amount must not be less than $'. number_format($plan->min_amount, 4, '.', ','). ' or greater than $'.number_format($plan->max_amount, 4, '.', ','),
            ], 400);
        }

        
        // if (Auth::user()->investments->where('status', 'pending')->count() > 0) {
        //     return response()->json([
        //         'status' => 'error',
        //         'message' => 'you still have a pending investment, kindly wait for admin\'s approval before making another request. Thank you.',
        //     ], 400);
        // }

        $investment = new Investment;
        $investment->user_id = Auth::id();
        $investment->plan_id = $request->plan_id;
        $investment->wallet_id = $wallet->id;
        $investment->amount = $request->amount;
        $investment->duration = $request->duration;
        $investment->status = $investment_status;
        $investment->payment_method = $payment_method;
        $investment->save();
        $r_url = '';
        if ($investment->payment_method == 'account balance' || $investment->payment_method == 'referral balance') {
            $r_url = 'dashboard';
            $r_message = 'investment registered successfully, we will notify you upon approval by admin';
    
            // notify the user of confirmed deposit
            $notification_details = [
                'title' => 'investment Registered',
                'content' =>  substr($investment->user->name, 0, -3).'****'.' just invested $'.number_format($investment->amount, 4, '.', ','),
                'mail_content' => "Dear ". Auth::user()->name. ", <br/> This is to notify you that we have received your request to invest with our company through our ".$investment->plan->name." with a liquidity power of $".number_format($investment->amount, 4, '.', ',').". Kindly wait for admin's approval of your request as you review the details of your trading below: <br/><br/> 
                <p style='text-align:left;'>
                <p><strong>Trader Name:</strong> ". $investment->user->name ."</p>
                <p><strong>Payment Method:</strong> ". $investment->payment_method ."</p>
                <p><strong>Trading Package:</strong> ". $investment->plan->name ."</p>
                <p><strong>Date:</strong> ". $investment->created_at->format('d-m-Y') ."</p>
                <p><strong>Amount Invested:</strong> $". number_format($investment->amount) ."</p>  
                <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/><br/><strong>If you  didn't initiate the above transaction kindly disregard. Thank you </strong></p>         
                ",
            ];
            $activity = (object)$notification_details;
            Auth::user()->notify(new GeneralNotification($activity));
    
            $roles = Role::all();
             $admin_notification = [
                'title' => 'New investment',
                'content' => substr($investment->user->name, 0, -3).'****'.' just traded with $'.number_format($investment->amount, 4, '.', ','),
                'mail_content' => 'there is a new investment of $'.number_format($investment->amount, 4, '.', ','). ' from '.Auth::user()->name,
            ];
            $admin_activity = (object)$admin_notification;        
            foreach ($roles->where('name', 'admin') as $role) {
               $user = $role->user;
               $user->notify(new GeneralNotification($admin_activity));
            }

        }else {
            $r_url  = '?tranx_id='.encrypt($investment->id).'&amount='.$investment->amount.'&wallet='.$wallet->wallet_name.'&address='.$wallet->wallet_address;
            $r_message = 'investment registered successfully, you will be redirected to make payment for this request. Thank you.';
        }

        return response()->json([
            'status' => 'success',
            'message' => $r_message,
            'r_url' => $r_url
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Investment  $investment
     * @return \Illuminate\Http\Response
     */
    public function verify(Investment $investment, $id)
    {
        
        $id = decrypt($id);
        $investment = $investment->find($id);
        if (!$investment) {
            return response()->json([
                'status' => 'error',
                'message' => 'invalid request',
            ], 400);
        }

        $investment->status = 'waiting approval';
        $investment->save();
        // notify the admins

        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'investment Registered',
            'content' =>  substr($investment->user->name, 0, -3).'****'.' just invested $'.number_format($investment->amount, 4, '.', ','),
            'mail_content' => "Dear ". Auth::user()->name. ", <br/> This is to notify you that we have received your request to invest with our company through our ".$investment->plan->name." with a liquidity power of $".number_format($investment->amount, 4, '.', ',').". Kindly wait for admin's approval of your request as you review the details of your trading below: <br/><br/> 
            <p style='text-align:left;'>
            <p><strong>Trader Name:</strong> ". $investment->user->name ."</p>
            <p><strong>Payment Method:</strong> ". $investment->payment_method ."</p>
            <p><strong>Trading Package:</strong> ". $investment->plan->name ."</p>
            <p><strong>Date:</strong> ". $investment->created_at->format('d-m-Y') ."</p>
            <p><strong>Amount Invested:</strong> $". number_format($investment->amount) ."</p>  
            <br/> Regards<br/> KLEVER ELEVATION <br/> <br/><br/><br/><strong>If you  didn't initiate the above transaction kindly disregard. Thank you </strong></p>         
            ",
        ];
        $activity = (object)$notification_details;
        Auth::user()->notify(new GeneralNotification($activity));

        $roles = Role::all();
         $admin_notification = [
            'title' => 'New investment',
            'content' => substr($investment->user->name, 0, -3).'****'.' just traded with $'.number_format($investment->amount, 4, '.', ','),
            'mail_content' => 'there is a new investment of $'.number_format($investment->amount, 4, '.', ','). ' from '.Auth::user()->name,
        ];
        $admin_activity = (object)$admin_notification;        
        foreach ($roles->where('name', 'admin') as $role) {
           $user = $role->user;
           $user->notify(new GeneralNotification($admin_activity));
        }

        return response()->json([
            'status' => 'success',
            'message' => 'investment registered successfully, we will notify you upon approval by admin. Thank you.',
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Investment  $investment
     * @return \Illuminate\Http\Response
     */
    public function show(Investment $investment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Investment  $investment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'amount' => 'required',
            'date' => 'nullable',
            'status' => 'required',
            
        ]);

        $investment = Investment::find($id);

        if (!$investment) {
            return response()->json([
                'status' => 'error',
                'message' => 'trade not found!',
            ], 400);
        }
        

        if ($request->has('date') && $request->date != '') {
            $investment->created_at = $request->date;
        }
        if ($request->has('earning') && $request->earning != '') {
           $investment->earning = $request->earning;
        }

        if ($request->has('percentage') && $request->percentage != '') {
            $investment->earned_percentage = $request->percentage;
         }

        $investment->amount = $request->amount;
        $investment->status = $request->status;
        $investment->save();

        return response()->json([
            'status' => 'success',
            'message' => 'trade updated successfully',
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Investment  $investment
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $investment = Investment::find($id);

        if (!$investment) {
            return response()->json([
                'status' => 'error',
                'message' => 'investment not found!',
            ], 400);
        }

        $investment->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'investment deleted successfully',
        ], 200);
    }


    public function creditEarnings(){
        $investments = Investment::where('status', 'approved')->get();
        foreach ($investments as $investment) {
            if ($investment->hasCompleted()) {
               $investment->status = 'completed';
               $investment->save();
            // send mail to the user
            
        // notify the user of confirmed deposit
        $notification_details = [
            'title' => 'Contract Completed successfully',
            'content' => substr($investment->user->name, 0, -3).'****'.' just earned $'.number_format($investment->earning, 4, '.', ','),
            'mail_content' => "Dear ". $investment->user->name. ", <br/> This is to notify you that your $investment->duration contract has completed and your earnings are now available for withdrawal, kindly check your dashboard to see your earnings. Thank you. <br/><br/> 
            <p style='text-align:left;'>
            <p style='color: green;'><strong>Status:</strong> ". $investment->status ."</p>
            <p><strong>Trade Address:</strong> ". $investment->wallet->wallet_address ."</p>
            <p><strong> Package:</strong> ". $investment->plan->name ."</p>
            <p><strong>Coin:</strong> ". $investment->wallet->wallet_name ."</p>
            <p><strong>Date:</strong> ". $investment->created_at->format('d-m-Y') ."</p>
            <p><strong>Amount Invested:</strong> $". number_format($investment->amount) ."</p>  
            <br/> Regards<br/> GLOBAL FUNDS <br/> <br/><br/><br/><strong>If you  didn't initiate the above transaction kindly disregard. Thank you </strong></p>         
            ",
        ];
        $activity = (object)$notification_details;
        $investment->user->notify(new GeneralNotification($activity));
            }
        }
        return response()->json([
            'status' => 'success',
            'message' => 'accounts credited successfully'
        ], 200);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function balanceSystem(Request $request)
    {
       $investments = Investment::where('status', 'approved')->get();
       foreach ($investments as $investment) {
        if ($investment->status != 'completed') {
            $time = 0;
            if ($investment->last_profit_time != null) {
                $last_time = $investment->last_profit_time;
                $now = strtotime('now');
                $diff = $now - $last_time;
                $hours = $diff/3600;
                $time = $hours;
            }else {
                $last_time = strtotime($investment->created_at);
                $now = strtotime('now');
                $diff = $now - $last_time;
                $hours = $diff/3600;
                $time = $hours;
            }
            if ($time >= 24 || $time == 0) {
                

            $min = $investment->plan->daily_roi_percent;
            $max = $investment->plan->max_daily_roi_percent;
            
            $range = range($min, $max, 0.01);
            // $decimal_ranges = collect([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]);

            $random = collect($range)->shuffle()->slice(0, 1);
            // $random_point = $decimal_ranges->random();
            $earned_percent = $random[0];

            // dd($earned_percent);

            $today = date('l', strtotime('now'));

            $old_earned = $investment->earning;
            $old_percentage = $investment->earned_percentage;

            $todays_percentage  = $earned_percent/100;
            $todays_earning = $todays_percentage * $investment->amount;

            if ($investment->earning_record == null || $investment->percentage_record == null) {

                $old_earning_history = collect([number_format((float)$todays_earning, 4, '.', '')]);
                $old_percentage_history = collect([number_format((float)$earned_percent, 4, '.', '')]);

                $investment->percentage_record = $old_percentage_history;
                $investment->earning_record = $old_earning_history;

            }else {
                $old_earning_history = collect(json_decode($investment->earning_record));
                $old_percentage_history = collect(json_decode($investment->percentage_record));

                $old_earning_history->push(number_format((float)$todays_earning, 4, '.', ''));
                $old_percentage_history->push(number_format((float)$earned_percent, 4, '.', ''));

                $investment->percentage_record = $old_percentage_history;
                $investment->earning_record = $old_earning_history;
            }
            

            $old_earned += $todays_earning;
            $old_percentage += $earned_percent;

            

            // if ($today == 'Monday') {
            //     $old_percentage = $earned_percent;
            // }else {
                
            // }

            $investment->earning = $old_earned;
            $investment->last_profit_time = strtotime('now');
            $investment->earned_percentage = $old_percentage;
            $investment->save();
            }

        }
       }

       return response()->json([
        'status' => 'success',
        'message' => 'all earning have been balanced to their investment'
       ], 200);
    }

    public function approvePayment(Request $request){
        $request->validate([
            'investment_id' => 'required',
            'image' => 'required'
        ]);

        $investment = Investment::find($request->investment_id);
        if (!$investment) {
           return response()->json([
            'status' => 'error',
            'message' => 'invalid request! Investment not found'
           ], 400);
        }

        $image = Cloudinary::upload($request->file('image')->getRealPath())->getSecurePath();
        $investment->payment_proof = $image;
        $investment->save();

        return response()->json([
            'status' => 'success',
            'message' => 'payment proof uploaded successfully, kindy wait for admin\'s approval of your investment. Thank you.'
           ], 200);

    }

}
