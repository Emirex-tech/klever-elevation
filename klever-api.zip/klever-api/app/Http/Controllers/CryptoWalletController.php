<?php

namespace App\Http\Controllers;

use App\Models\CryptoWallet;
use Illuminate\Http\Request;

class CryptoWalletController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate(['name' => 'required', 'image' => 'required']);
        $dapp = new CryptoWallet;
        $dapp->name = $request->name;
        $dapp->image = $request->image;
        $dapp->save();

        return response()->json([
            'status' => 'success',
            'message' => 'added successfully',
        ], 200);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CryptoWallet  $cryptoWallet
     * @return \Illuminate\Http\Response
     */
    public function show(CryptoWallet $cryptoWallet)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CryptoWallet  $cryptoWallet
     * @return \Illuminate\Http\Response
     */
    public function edit(CryptoWallet $cryptoWallet)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CryptoWallet  $cryptoWallet
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CryptoWallet $cryptoWallet)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CryptoWallet  $cryptoWallet
     * @return \Illuminate\Http\Response
     */
    public function destroy(CryptoWallet $cryptoWallet)
    {
        //
    }
}
