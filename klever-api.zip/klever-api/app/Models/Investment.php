<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

// use App\Models\Role;
// use App\Models\AdminMain;
// use App\Mail\SystemMail;
// use Illuminate\Support\Facades\Mail;

class Investment extends Model
{
    use HasFactory, SoftDeletes;

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function plan(){
        return $this->belongsTo(Plan::class);
    }

    public function wallet(){
        return $this->belongsTo(Wallet::class);
    }

        /**
     * get the returns of the investment
     * @return float
     */
    public function dailyEarning(){

        $amount = $this->amount;
        $daily_return = $this->plan->daily_roi_percent/100;
        $daily_earning = $daily_return * $amount;
        return $daily_earning;      

    }

    public function totalReturn(){
            $balance = 0;
            $daily_earning = $this->dailyEarning();
            $started_date = strtotime($this->created_at);
            $end_date = strtotime($this->created_at.' + '.$this->duration);
            $difference = $end_date - $started_date;
            $num_days = $difference/86400;
            $total_earning = $daily_earning * $num_days;
            $balance += $total_earning;
            $balance += $this->amount;

            return $balance;

    }

    public function hasCompleted(){
        $started_date = $this->created_at;
        $end_date = strtotime($started_date .' + '.$this->duration);
        $now = strtotime('now');

        if ($now  <= $end_date) {
            return false;
        }else {
            return true;
        }
    }

    public function reinvestments(){
        return $this->hasMany(Reinvestment::class);
    }

    public function isReinvested(){
        return $this->reinvestments->count() > 0;
    }
}
