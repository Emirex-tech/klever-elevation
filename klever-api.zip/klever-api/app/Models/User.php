<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'enc_copy',
        'country',
        'phone',
        'profile',
        'account_number'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function investments(){
        return $this->hasMany(Investment::class);
    }

    public function roles(){
        return $this->hasMany(Role::class);
    }

    public function isAdmin(){
        return $this->roles->where('name', 'admin')->count() > 0;
    }

    public function withdrawals(){
        return $this->hasMany(Withdrawal::class);
    }

    public function referrals(){
        return $this->hasMany(Referral::class, 'inviter_id');
    }

    public function invited(){
        return $this->hasOne(Referral::class, 'invited_id');
    }
    

    public function isInvited(){
        return $this->invited;
    }

    public function reinvestments(){
        return $this->hasMany(Reinvestment::class);
    }

    public function topUps(){
        return $this->hasMany(TopUp::class);
    }

    public function topDowns(){
        return $this->hasMany(TopDown::class);
    }

    public function topUpBal(){
        $bal = 0;
        $tops =  $this->topUps->sum('amount');
        $withdrawn = $this->withdrawals->where('status', 'approved')->where('source', 'bonus')->sum('amount');
        $bal = $tops - $withdrawn;
        return $bal;
    }

    public function topDownBal(){
        return $this->topDowns->sum('amount');
    }

    public function debits(){
        return $this->hasMany(Transfer::class);
    }

    public function credits(){
        return $this->hasMany(Transfer::class, 'receiver_id');
    }
    
    public function accountBalance(){
        $balance = 0;
        $fundings = $this->fundings->where('status', 'approved')->sum('amount');
        $topdowns = $this->topDownBal();
        $topups = $this->topUpBal();
        $credits = $this->credits->where('status', 'approved')->sum('amount');
        $debits = $this->debits->where('status', 'approved')->sum('amount');
        $reinvestments = $this->reinvestments->where('status', 'approved')->where('source', 'investment')->sum('amount');

        foreach ($this->investments->where('status', 'completed') as $investment) {
           $earning = $investment->earning;
           $amount = $investment->amount;
           $balance += $earning;
           $balance += $amount;
        }

        foreach ($this->investments->where('status', 'approved') as $investment) {
            $earning = $investment->earning;
            $balance += $earning;
         }

        $withdrawals = $this->withdrawals->where('status', 'approved')->where('source', 'investment')->sum('amount');
        $balance = $balance  - $withdrawals - $topdowns + $topups - $reinvestments + $credits - $debits + $fundings;
        return $balance;
    }

    public function referralBalance(){
        $withdrawals = $this->withdrawals->where('status', 'approved')->where('source', 'referral')->sum('amount');
        $referrals = $this->referrals->where('status', 'approved')->sum('amount');
        $reinvestments = $this->reinvestments->where('status', 'approved')->where('source', 'referral')->sum('amount');
        $balance = $referrals  - $withdrawals - $reinvestments;
        return $balance;
    }

    public function perSecondEarning(){
        $balance = 0;
        foreach ($this->investments->where('status', 'approved') as $investment) {
            $daily_earning = $investment->dailyEarning();
            $seconds_earnings = $daily_earning/86400;
            $balance += $seconds_earnings;
        }
        return $balance;
    }

    public function currentEarning(){
        $balance = 0;
        foreach ($this->investments->where('status', 'approved') as $investment) {
            $daily_earning = $investment->dailyEarning();
            $started_date = strtotime($investment->created_at);
            $end_date = strtotime($investment->created_at.' + '.$investment->duration);
            $now = strtotime('now');
            if ($end_date >= $now) {

                $difference = $now - $started_date;
                $num_days = $difference/86400;
                $total_earning = $daily_earning * $num_days;
                $balance += $total_earning;
            }else {

                $daily_earning = $investment->dailyEarning();
                $started_date = strtotime($investment->created_at);
                $end_date = strtotime($investment->created_at.' + '.$investment->duration);
                $difference = $end_date - $started_date;
                $num_days = $difference/86400;
                $total_earning = $daily_earning * $num_days;
                $balance += $total_earning;
            }
            
        }
        return $balance;
    }

    public function totalInvestments(){
        $balance = 0;
        foreach ($this->investments->where('status', '!=', 'pending')->where('status', '!=', 'declined')->where('status', '!=', 'waiting approval') as $investment) {
            $balance += $investment->amount;
        }

        return $balance;
    }

    public function totalWithdrawals(){
        $balance = 0;
        foreach ($this->withdrawals->where('status', 'approved') as $withdrawal) {
            $balance += $withdrawal->amount;
        }

        return $balance;
    }

    public function totalreferrals(){
        $balance = 0;
        foreach ($this->referrals->where('status', 'approved') as $referrals) {
            $balance += $referrals->amount;
        }
        return $balance;
    }

    public function fundings(){
        return $this->hasMany(Funding::class);
    }

}
