<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Referral extends Model
{
    use HasFactory, SoftDeletes;

    public function inviter(){
        return $this->belongsTo(User::class, 'inviter_id');
    }

    public function invited(){
        return $this->belongsTo(User::class, 'invited_id');
    }
    
}
