<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
	<!--[if gte mso 9]>
	<xml>
		<o:OfficeDocumentSettings>
		<o:AllowPNG/>
		<o:PixelsPerInch>96</o:PixelsPerInch>
		</o:OfficeDocumentSettings>
	</xml>
	<![endif]-->
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="date=no" />
	<meta name="format-detection" content="address=no" />
	<meta name="format-detection" content="telephone=no" />
	<meta name="x-apple-disable-message-reformatting" />
    <!--[if !mso]><!-->
   	<link href="https://fonts.googleapis.com/css?family=Kreon:400,700|Playfair+Display:400,400i,700,700i|Raleway:400,400i,700,700i|Roboto:400,400i,700,700i" rel="stylesheet" />
    <!--<![endif]-->
	<title>ELLIPTIC MANAGEMENT </title>
	<!--[if gte mso 9]>

	<style type="text/css" media="all">
		sup { font-size: 100% !important; }
	</style>
	<![endif]-->
	

	<style type="text/css" media="screen">
		/* Linked Styles */
		body { padding:0 !important; margin:0 !important; display:block !important; min-width:100% !important; width:100% !important; background:white; -webkit-text-size-adjust:none }
		a { color:#000001; text-decoration:none }
		p { padding:0 !important; margin:0 !important } 
		img { -ms-interpolation-mode: bicubic; /* Allow smoother rendering of resized image in Internet Explorer */ }
		.mcnPreviewText { display: none !important; }
		.text-footer2 a { color: #ffffff; } 
		
		/* Mobile styles */
		@media only screen and (max-device-width: 480px), only screen and (max-width: 480px) {
			.mobile-shell { width: 100% !important; min-width: 100% !important; }
			
			.m-center { text-align: center !important; }
			.m-left { text-align: left !important; margin-right: auto !important; }
			
			.center { margin: 0 auto !important; }
			.content2 { padding: 8px 15px 12px !important; }
			.t-left { float: left !important; margin-right: 30px !important; }
			.t-left-2  { float: left !important; }
			
			.td { width: 100% !important; min-width: 100% !important; }

			.content { padding: 30px 15px !important; }
			.section { padding: 30px 15px 0px !important; }

			.m-br-15 { height: 15px !important; }
			.mpb5 { padding-bottom: 5px !important; }
			.mpb15 { padding-bottom: 15px !important; }
			.mpb20 { padding-bottom: 20px !important; }
			.mpb30 { padding-bottom: 30px !important; }
			.mp30 { padding-bottom: 30px !important; }
			.m-padder { padding: 0px 15px !important; }
			.m-padder2 { padding-left: 15px !important; padding-right: 15px !important; }
			.p70 { padding: 30px 0px !important; }
			.pt70 { padding-top: 30px !important; }
			.p0-15 { padding: 0px 15px !important; }
			.p30-15 { padding: 30px 15px !important; }			
			.p30-15-0 { padding: 30px 15px 0px 15px !important; }			
			.p0-15-30 { padding: 0px 15px 30px 15px !important; }			


			.text-footer { text-align: center !important; }

			.m-td,
			.m-hide { display: none !important; width: 0 !important; height: 0 !important; font-size: 0 !important; line-height: 0 !important; min-height: 0 !important; }

			.m-block { display: block !important; }

			.fluid-img img { width: 100% !important; max-width: 100% !important; height: auto !important; }

			.column,
			.column-dir,
			.column-top,
			.column-empty,
			.column-top-30,
			.column-top-60,
			.column-empty2,
			.column-bottom { float: left !important; width: 100% !important; display: block !important; }

			.column-empty { padding-bottom: 15px !important; }
			.column-empty2 { padding-bottom: 30px !important; }

			.content-spacing { width: 15px !important; }
		}
	</style>
</head>
	
                        <body class="body"style="padding:0 !important; margin:0 !important; display:block !important; min-width:100% !important; width:100% !important; background: #FFFFFF !important; -webkit-text-size-adjust:none;">
<!--*|IF:MC_PREVIEW_TEXT|*-->
		<!--[if !gte mso 9]><!-->
		<span class="mcnPreviewText" style="display:none; font-size:0px; line-height:0px; max-height:0px; max-width:0px; opacity:0; overflow:hidden; visibility:hidden; mso-hide:all;">ELLIPTIC MANAGEMENT </span>
		<!--<![endif]-->
	<!--*|END:IF|*-->
	<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F6F8FA">
		<tr>
			<td align="center" valign="top">
				<!-- Main -->
				<table width="650" bgcolor="#ffffff" style="background-color: #FFFFFF !important;"  border="0" cellspacing="0" cellpadding="0" class="mobile-shell">
					<tr>
						<td class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;">
							<!-- Header -->
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<!-- Logo -->
								<tr>
									<td bgcolor="#ffffff" class="p30-15 img-center" style="padding: 30px; border-radius: 20px 20px 0px 0px; font-size:0pt; line-height:0pt; text-align:center; background-image:url(https://res.cloudinary.com/dzxyvdq14/image/upload/v1635586601/dark_bg.png);"><a href="#" target="_blank"><img src="https://res.cloudinary.com/djxs33vuk/image/upload/v1747915853/logo-dark_lrxuz1.png" width="133" height="33" mc:edit="image_6" style="max-width: 300px;" border="0" alt="" /></a></td>
								</tr>
								<!-- END Logo -->
							</table>
							<!-- END Header -->
								
							<!-- Section 1 -->
							<div mc:repeatable="Select" mc:variant="Section 1">
								<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ebebeb" style="background-color: #ebebeb !important;">
									
									<tr>
										<td class="p30-15-0" style="padding: 50px 30px 0px; background-color: #070707 !important;">
											<table width="100%" border="0" cellspacing="0" cellpadding="0">
												
												<tr>
													<td class="h2-center"style="color:#FFFFFF !important; font-family:'Playfair Display', Times, 'Times New Roman', serif; font-size:24px; line-height:36px; text-align:center; padding-bottom:20px;"><div mc:edit="text_4"><?php echo $title; ?></div></td>
												</tr>
												<tr>
													<td class="text-left"style="color:#FFFFFF !important; font-family:'Raleway', Arial,sans-serif; font-size:14px; line-height:22px; text-align:left; padding-bottom:22px;"><div mc:edit="text_5" style="color: #FFFFFF !important;">
                                                    <?php echo $content; ?></div></td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</div>
							<!-- END Section 1 -->
							
							<!-- Footer -->
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td class="p30-15-0" bgcolor="#232324" style="border-radius: 0px 0px 20px 20px; padding: 70px 30px 0px 30px; background-color:#232324 !important;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td align="center" class="p30-15" style="border-top: 1px solid #ebebeb; padding: 30px;">
													<table class="center" border="0" cellspacing="0" cellpadding="0"style="text-align:center;">
														<tr>
															<th class="column-top" width="180"style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td class="text-footer"style="color:#F8FAFC; font-family:'Raleway', Arial,sans-serif; font-size:13px; line-height:22px; text-align:left;">
																			
																		</td>
																	</tr>
																</table>
															</th>
															<th class="column-empty" width="20"style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; direction:ltr;"></th>
															<th class="column-top" width="180"style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td class="text-footer"style="color:#F8FAFC; font-family:'Raleway', Arial,sans-serif; font-size:13px; line-height:22px; text-align:left;">
																			<div mc:edit="text_56">
																				<strong>Need Help</strong><br />
																				<a href="<?php echo e(url('https://dashboard.ellipticmanagement.com')); ?>" target="_blank" class="link-grey"style="color:#F8FAFC; text-decoration:none;"><span class="link-grey"style="color:#F8FAFC; text-decoration:none;">FAQ</span></a><br />
																				<a href="<?php echo e(url('https://dashboard.ellipticmanagement.com')); ?>" target="_blank" class="link-grey"style="color:#F8FAFC; text-decoration:none;"><span class="link-grey"style="color:#F8FAFC; text-decoration:none;">Contact Us</span></a><br />
																			</div>
																		</td>
																	</tr>
																</table>
															</th>
															<th class="column-empty" width="20"style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; direction:ltr;"></th>
															<th class="column-top" width="180"style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td class="text-footer"style="color:#F8FAFC; font-family:'Raleway', Arial,sans-serif; font-size:13px; line-height:22px; text-align:left;">
																			<div mc:edit="text_57">
																				<strong>Account</strong><br />
																				<a href="https://dashboard.ellipticmanagement.com" target="_blank" class="link-grey"style="color:#F8FAFC; text-decoration:none;"><span class="link-grey"style="color:#F8FAFC; text-decoration:none;">Register</span></a> <br />
																				<a href="https://dashboard.ellipticmanagement.com" target="_blank" class="link-grey"style="color:#F8FAFC; text-decoration:none;"><span class="link-grey"style="color:#F8FAFC; text-decoration:none;">Login</span></a>
																				<a href="https://dashboard.ellipticmanagement.com" target="_blank" class="link-grey"style="color:#F8FAFC; text-decoration:none;"><span class="link-grey"style="color:#F8FAFC; text-decoration:none;">Dashboard</span></a>
																			</div>
																		</td>
																	</tr>
																</table>
															</th>
														</tr>
													</table>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0" style="backgrund-color: #000000 !important;">
								<tr>
									<td class="text-footer2 p30-15" style="backgrund-color: #000000 !important; padding: 30px 15px 50px 15px; color:#a9b6e0; font-family:'Raleway', Arial,sans-serif; font-size:12px; line-height:22px; text-align:center;">
										<div mc:edit="text_58">Want to change how you receive these emails? <br />You can <a class="link-white" target="_blank" href="https://dashboard.ellipticmanagement.com"style="color:#000000; text-decoration:none;">update your preferences</a> or <a class="link-white" target="_blank" href="https://dashboard.ellipticmanagement.com"style="color:#000000; text-decoration:none;">unsubscribe</a> from this list.</div>
									</td>
								</tr>
								
							</table>
							<!-- END Footer -->
						</td>
					</tr>
				</table>
				<!-- END Main -->

			</td>
		</tr>
	</table>
</body>
    
</html>
<?php /**PATH /home/u297572638/domains/ellipticmanagement.com/public_html/api/resources/views/mail/general.blade.php ENDPATH**/ ?>