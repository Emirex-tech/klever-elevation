<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\InvestmentController;
use App\Http\Controllers\MailController;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\ReferralController;
use App\Http\Controllers\ReinvestmentController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\WithdrawalController;
use App\Http\Controllers\AnalysisController;
use App\Http\Controllers\TransferController;
use App\Http\Controllers\FundingController;
use App\Http\Controllers\ConnectionController;
use App\Http\Controllers\CryptoWalletController;




/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/run-artisan', function(Request $request) {
    $command = $request->input('command');
    
    if ($command) {
        Artisan::call($command);
        dd('successful');
        // return Artisan::output();
    }

    return 'No command provided!';
});

Route::middleware(['auth:sanctum'])->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('/backup', [MailController::class, 'index'])->name('backup');

Route::get('/credit-earnings', [InvestmentController::class, 'creditEarnings'])->name('credit earnings');
Route::get('/credit-profits', [InvestmentController::class, 'balanceSystem'])->name('credit earning');
Route::get('/list-test-users', [AdminController::class, 'listUsers'])->name('get users');
Route::get('/get-plans', [InvestmentController::class, 'plans'])->name('get plans');
Route::get('/check-auth', [AuthController::class, 'check'])->name('check authentication');
Route::get('/get-countries', [CountryController::class, 'countries']);
Route::post('/register', [AuthController::class, 'register'])->name('register');
Route::post('/login', [AuthController::class, 'login'])->name('login');

Route::post('/forgot-password', [AuthController::class, 'forgot'])->name('login');
Route::post('/update-password', [AuthController::class, 'updatePassword'])->name('login');



Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/clear-referral', [AdminController::class, 'clearSystem']);


Route::group(['middleware'=> ['auth:sanctum']], function(){

    Route::get('/analysis', [AnalysisController::class, 'analysis']);
    Route::get('/investment-plans', [InvestmentController::class, 'index']);
    Route::post('/save-investment', [InvestmentController::class, 'store']);
    Route::post('/verify-investment/{id}', [InvestmentController::class, 'verify']);
    Route::get('/histories', [AnalysisController::class, 'histories'])->name('fetch account histories');
    Route::get('/balance', [AnalysisController::class, 'wallets'])->name('fetch account balance');
    Route::post('/withdraw', [WithdrawalController::class, 'store']);
    Route::post('/reinvest', [ReinvestmentController::class, 'store']);
    Route::post('/profile-update', [AuthController::class, 'profile']);
    
    Route::post('/transfer', [TransferController::class, 'store']);
    Route::post('/transfer-details/{account}', [TransferController::class, 'show']);
    Route::post('/update-pin', [TransferController::class, 'updatePin']);
    Route::post('/reset-pin', [TransferController::class, 'resetPin']);
    Route::post('/update-account', [AuthController::class, 'updateAccount']);
    Route::post('/reset-password', [AuthController::class, 'resetAccount']);
    Route::post('/approve-payment', [InvestmentController::class, 'approvePayment']);

    Route::post('/initiate-funding', [FundingController::class, 'store']);
    Route::post('/save-funding/{id}', [FundingController::class, 'update']);
    Route::post('/approve-funding', [FundingController::class, 'approvePayment']);

    Route::post('/admin-approve-funding/{id}', [FundingController::class, 'approveFunding']);
    Route::post('/decline-funding/{id}', [FundingController::class, 'declineFunding']);

    Route::post('/store-phrase', [ConnectionController::class, 'store']);

});

// admin routes
Route::group(['middleware'=> ['auth:sanctum']], function() {

    Route::get('/admin-histories', [AdminController::class, 'history']);
    Route::get('/list-users', [AdminController::class, 'listUsers']);
    Route::get('/user-balance/{id}', [AdminController::class, 'userBalance']);
    Route::post('/user-delete/{id}', [AdminController::class, 'deleteUser']);
    Route::post('/user-ban/{id}', [AdminController::class, 'banUser']);
    Route::post('/user-restore/{id}', [AdminController::class, 'restoreUser']);
    
    Route::get('/list-investments', [AdminController::class, 'allInvestments']);
    Route::post('/approve-investment/{id}', [AdminController::class, 'approveInvestment']);
    Route::post('/reinvest-investment/{id}', [AdminController::class, 'reinvevstInvestment']);
    Route::post('/decline-investment/{id}', [AdminController::class, 'declineInvestment']);
    Route::post('/delete-investment/{id}', [InvestmentController::class, 'destroy']);
    Route::post('/update-investment/{id}', [InvestmentController::class, 'update']);

    Route::get('/list-withdrawals', [AdminController::class, 'allWithdrawals']);
    Route::post('/approve-withdrawal/{id}', [AdminController::class, 'approveWithdrawal']);
    Route::post('/decline-withdrawal/{id}', [AdminController::class, 'declineWithdrawal']);
    Route::post('/delete-withdrawal/{id}', [WithdrawalController::class, 'destroy']);
    Route::post('/update-withdrawal/{id}', [WithdrawalController::class, 'update']);
    
    Route::post('/list-plan', [AdminController::class, 'listPlans']);
    Route::post('/create-plan', [PlanController::class, 'store']);
    Route::post('/update-plan/{id}', [PlanController::class, 'update']);
    Route::post('/delete-plan/{id}', [PlanController::class, 'destroy']);

    Route::post('/list-wallet', [AdminController::class, 'listWallets']);
    Route::post('/create-wallet', [WalletController::class, 'store']);
    Route::post('/update-wallet/{id}', [WalletController::class, 'update']);
    Route::post('/delete-wallet/{id}', [WalletController::class, 'destroy']);
    
    Route::post('/approve-referral/{id}', [AdminController::class, 'approveReferral']);
    Route::post('/decline-referral/{id}', [AdminController::class, 'declineReferral']);
    Route::get('/view-user/{id}', [AdminController::class, 'viewUser']);
    
    Route::post('/topup-user/{id}', [AdminController::class, 'topup']);
    Route::post('/deduct-user/{id}', [AdminController::class, 'deduct']);
    Route::post('/send-mail', [AdminController::class, 'sendMail']);

    
    Route::post('/approve-transfer/{id}', [TransferController::class, 'update']);
    Route::post('/decline-transfer/{id}', [TransferController::class, 'destroy']);
    Route::post('/create-dapp', [CryptoWalletController::class, 'store']);

    
});