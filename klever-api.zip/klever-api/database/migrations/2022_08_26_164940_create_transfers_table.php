<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransfersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transfers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id');
            $table->foreignId('receiver_id')->nullable();
            $table->decimal('amount', 20, 2);
            $table->string('status');
            $table->string('account_number')->nullable();
            $table->string('transfer_type');
            $table->string('interAccountNumber')->nullable();
            $table->string('receiverEmail')->nullable();
            $table->string('bankName')->nullable();
            $table->string('swiftCode')->nullable();
            $table->string('routineNumber')->nullable();
            $table->string('country')->nullable();
            $table->string('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transfers');
    }
}
